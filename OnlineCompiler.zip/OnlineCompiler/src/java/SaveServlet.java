
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import static com.oracleconnection.Connections.*;

@WebServlet(urlPatterns = {"/save"})
public class SaveServlet extends HttpServlet 
{
 public String getTempId()
    {
        String ti="";
        for(int i=1;i<=20;)
        {
            int num=(int)(91*Math.random());
            if(num<65)
            {
                continue;
            }
            i=i+1;
            ti=ti+(char)num;
        }
        return ti;  
    }    
    
    
    int port;
    @Override
    protected void service(HttpServletRequest req, 
            HttpServletResponse resp)throws ServletException, IOException
            
    {
        port=req.getServerPort();
        try
        {
            String s1=req.getParameter("name");
            String s2=req.getParameter("email");
            String s3=req.getParameter("passwrd");
            String s4=req.getParameter("contact");
            String s5=req.getParameter("gender");
            String ti=getTempId();
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            long time=timestamp.getTime();
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","123");
            Statement st=c.createStatement();
            //Statement st=getOracleConnection();
            int n=st.executeUpdate("insert into com_project_users values('"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"','N','"+ti+"')");
            if(n!=0)
                resp.sendRedirect("registered.html");
            else
                resp.sendRedirect("notregisterd.html");
            //closeOracleConnection();
            st.close();
            c.close();
            sendMail(s2,ti,time);
            
            
        }catch(Exception e)
        {
            System.out.println(e);
        }
    }


    
public void sendMail(String email,String tempid,long time)
    {
        try
        {
            String user="divyanshnigam365";
            String password="kanpur@123";
            String host="smtp.gmail.com";
            String sender="divyanshnigam365@gmail.com";
            String port="465";
            
            Properties props=new Properties();
            props.put("mail.smtp.host",host);
            props.put("mail.smtp.user",user);
            props.put("mail.smtp.password", password);
            props.put("mail.smtp.port",port);
            props.put("mail.smtps.auth", true);
            
            
            Session session=Session.getDefaultInstance(props);
            
            MimeMessage message=new MimeMessage(session);
            
            InternetAddress sen=new InternetAddress(sender);
            message.setSender(sen);
            
            
            InternetAddress rec=new InternetAddress(email);
            message.setRecipient(Message.RecipientType.TO,rec);
            message.setSubject("Email Confirmation Mail From Cloud Compiler");
            
            InetAddress address=InetAddress.getLocalHost();
            String ip=address.getHostAddress();
        message.setContent("Dear Sir/Ma'am<br><br><br>Greetings From Online Compiler!!!!<br><br>"
                + "Thanks For Registering On Online Compiler, You can compile any program in this web tool<br>"
                + "<b>Please click or copy paste link given below on browser and verify yourself</b><br><br>"
                + "http://"+ip+":"+this.port+"/OnlineCompiler/verify?email="+tempid+"&time="+time+"<br><br>Thanks,<br>Technical Team", "text/html");
        Transport t=session.getTransport("smtps");
        t.connect(host, user, password);
        t.sendMessage(message, message.getAllRecipients());
          
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
   
}

