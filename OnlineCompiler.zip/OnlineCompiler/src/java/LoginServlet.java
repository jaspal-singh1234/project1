import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import static com.oracleconnection.Connections.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.http.Cookie;

@WebServlet(urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet 
{
    int count;
    protected void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException 
    {
        try
        {
            String s1=req.getParameter("email");
            String s2=req.getParameter("pass");
            //Statement st=getOracleConnection();
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","123");
            Statement st=c.createStatement();
            
            ResultSet rs=st.executeQuery("select * from com_project_users where email='"+s1+"' and PASSWD='"+s2+"'");
            if (rs.next())
            {
                String s=rs.getString("status");
                if(s.equals("Y"))
                {
                        count=0;
                        Cookie ck1=new Cookie("cn", count+"");
                        resp.addCookie(ck1);
                }
                else
                {
                    resp.sendRedirect("loginunauth.html");
                }
            }
            else
            {
                count=0;
                Cookie ck[]=req.getCookies();
                if(ck!=null&&ck.length!=0){
                    count=Integer.parseInt(ck[0].getValue());
                }
                count++;
                Cookie ck1=new Cookie("cn", count+"");
                resp.addCookie(ck1);
                if(count>6)
                    resp.sendRedirect("logincap.html");
                else
                    resp.sendRedirect("logininvalid.html");
            }
            //closeOracleConnection();
            st.close();
            c.close();
        }catch(Exception e)
        {
            System.out.println(e);
        }
        
    }

}
