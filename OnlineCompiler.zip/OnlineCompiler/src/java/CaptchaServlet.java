import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.PrintWriter;
import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(urlPatterns = {"/captcha"})
public class CaptchaServlet extends HttpServlet 
{

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        BufferedImage img=new BufferedImage(120, 30, 
                BufferedImage.TYPE_INT_RGB);
        Graphics g=img.getGraphics();
        g.setColor(Color.RED);
        g.drawRect(0, 0, 130, 30);
        g.fillRect(0, 0, 130, 30);
        g.setColor(Color.white);
        Font font=new Font("Tahoma",Font.BOLD,20);
        g.setFont(font);
        String cap=getCapText();
        g.drawString(cap, 20, 22);
        ServletOutputStream out=resp.getOutputStream();
        ImageIO.write(img, "PNG", out);
    }
    public String getCapText()
    {
        String cap="";
        String req="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        int len=req.length();
        for(int i=1;i<=6;i++)
        {
            int index=(int)(len*Math.random());
            cap+=req.charAt(index);
        }
        return cap;
    }
       
}
