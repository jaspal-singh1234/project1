/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.Timestamp;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns = {"/verify"})
public class VerifyServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try
        {
            String ti=req.getParameter("email");
            long tp=Long.parseLong(req.getParameter("time"));
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            long ctime=timestamp.getTime();
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection c = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:XE",
                    "system", "123");
            Statement st = c.createStatement();
            if((ctime-tp)<=86400000)
            //if((ctime-tp)<=100)
            {
            int num=st.executeUpdate("update com_project_users set status='Y' where  tempid='"+ti+"' ");
             if(num>0)
                resp.sendRedirect("verify.html");
            else
                resp.sendRedirect("unverify.html");
            }
            else
            {
                resp.sendRedirect("unverify.html");
            }
           
            //PrintWriter pw = resp.getWriter();
            //pw.println("Now you are verified");
        }
        
        catch(Exception e)
        {
        System.out.println(e);
        }
    }

}
