package com.oracleconnection;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
public class Connections 
{
    static Connection c;
    static Statement st;
    public static Statement getOracleConnection()
    {
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","123");
            st=c.createStatement();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    return st;
    }
    public static Statement closeOracleConnection()
    {
        try
        {
            st.close();
            c.close();
           
        }catch(Exception e)
        {
            System.out.println(e);
        } 
        return st;
    }
}
